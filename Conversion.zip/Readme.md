##Conversion.com: Tech challenge
#####By: Joseph holder

###Developer tools used:
IDE: php storm  
Languages: HTML5, CSS, JavaScript(ECMAscript 5)  
Assets: contains a normalize css and cut out images for web

###Explanation
Each answer is found in the corresponding file name. 
The structure used are to contain all the code for that question in a single file.

I have completed questions 1 - 3.

Question one - Has a normalize css file and attached to it externally - as it is an external source not to be treated as my work.  
For reference I have not had the change to find the correct font with out paying for it, the default is Ariel.

Question 2 and 3 are simple query changes they are contained with in a js file.