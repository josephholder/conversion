$("[name='budget']").click(function() {
    alert('Budget for CRO: ' + this.value);
});